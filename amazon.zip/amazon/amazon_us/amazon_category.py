import requests
import re
import redis
from lxml import etree
from fake_useragent import UserAgent


class AmazonSpiderShop(object):
    def __init__(self):
        '''//span[@data-component-type="s-search-results"]/div[2]/div[2]/div/div/div/div/div/div/div/span/a/@href'''
        self.r = redis.Redis(host='192.168.1.4', port=6776, db=0, decode_responses=True)
        self.cache_queue = 'amazon_category_url'

    def am_request(self):
        location = r'C:\Users\Administrator\Desktop\测试\amazon\amazon_us\fake_useragent_0.1.11.json'
        ua = UserAgent(path=location).random
        headers = {
                      'authority': 'www.amazon.com',
                      'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                      'accept-language': 'zh-CN,zh;q=0.9',
                      'user-agent': ua,
        }
        r = requests.get(url=self.amazon_url, headers=headers)
        return r.text

    def am_data(self, response_data):
        # amazon_html = etree.HTML(response_data)
        # amazon_goods_url_list = amazon_html.xpath('//span[@data-component-type="s-search-results"]/div[2]/div/div/div/div/div/div/div/div/span/a/@href')
        page_num = re.search(r'aria-disabled="true">(\d+)<', response_data)
        if page_num == None:
            self.r.sadd(self.cache_queue, self.amazon_url)
        else:
            int_page_num = int(page_num.group(1))+1
            for num in range(1, int_page_num):
                amazon_category_url = self.amazon_url + '&page={}'.format(num)
                self.r.sadd(self.cache_queue, amazon_category_url)


    def run_amazon_spider(self):
        with open(r'amazon_shopinfo.txt', 'r', encoding='utf-8') as url_list:
            for url in url_list:
                self.amazon_url = 'https://www.amazon.com' + url
                response_data = self.am_request()
                re_response_data = self.am_data(response_data)
        # for page in range(3, 401):
        #     amazon_url = 'https://www.amazon.com/s?i=electronics-intl-ship&bbn=16225009011&rh=n%3A16225009011%2Cn%3A281407&page={}&qid=1666181786&ref=sr_pg_{}'.format(page, page)
        #     response_data = self.am_request(amazon_url)
        #     re_response_data = self.am_data(response_data)


def am_run_spider():
    run_amazon = AmazonSpiderShop()
    run_amazon.run_amazon_spider()


if __name__ == '__main__':
    am_run_spider()






