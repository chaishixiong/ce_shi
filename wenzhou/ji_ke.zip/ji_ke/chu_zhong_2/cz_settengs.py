s_x_point_id_list = {"10334479": "数与式",
                     "10334574": "方程与不等式",
                     "10334670": "函数",
                     "10334867": "图形的性质",
                     "10334970": "图形的变化",
                     "10335016": "统计与概率",
                     "10335030": "专题与拓展"}
y_w_point_id_list = []
y_y_point_id_list = {
                     "13042846": "语音",
                     "13042847": "词汇",
                     "13042848": "词法",
                     "13042849": "句法",
                     "13042850": "功能意念",
                     "13042851": "阅读",
                     "13042852": "写作",
                     "13042853": "主题语境",
}
w_l_point_id_list = []
h_x_point_id_list = []
l_s_point_id_list = []
d_l_point_id_list = []
s_w_point_id_list = []
k_x_point_id_list = []
lsysh_point_id_list = []
ddyfz_point_id_list = []
